Greetings, dear player,

Here is VladimirVV, and this is a short letter with some important information.

-All the story-critical markets in this mod are by default protected from decivilization. 

	If you don't want this, please find the setting.json file at the following address:

	...\Starsector\mods\Domain Phase Lab\data\config\setting.json

	And change the line that says:

	"dpl_Do_Not_Protect_Important_Planets":false,

	into:

	"dpl_Do_Not_Protect_Important_Planets":true,

	Please Include the comma (,)!

-All the source codes for whatever inside the .jar file are just included in the data directories.

	So you can just view the .java files in those folders for reference.

I hope this information is helpful, please enjoy, and have a great day!

--Best Wishes

VladimirVV