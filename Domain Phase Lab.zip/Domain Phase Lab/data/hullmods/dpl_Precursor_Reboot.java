package data.hullmods;

import java.awt.Color;

import org.lwjgl.util.vector.Vector2f;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.combat.ArmorGridAPI;
import com.fs.starfarer.api.combat.BaseHullMod;
import com.fs.starfarer.api.combat.MutableShipStatsAPI;
import com.fs.starfarer.api.combat.ShipAPI;
import com.fs.starfarer.api.combat.ShipAPI.HullSize;
import com.fs.starfarer.api.combat.ShipCommand;
import com.fs.starfarer.api.combat.ShipSystemAPI.SystemState;
import com.fs.starfarer.api.combat.listeners.AdvanceableListener;
import com.fs.starfarer.api.combat.listeners.HullDamageAboutToBeTakenListener;
import com.fs.starfarer.api.impl.campaign.ids.HullMods;
import com.fs.starfarer.api.impl.campaign.ids.Strings;
import com.fs.starfarer.api.impl.campaign.skills.NeuralLinkScript;
import com.fs.starfarer.api.util.FaderUtil;
import com.fs.starfarer.api.util.Misc;

public class dpl_Precursor_Reboot extends BaseHullMod {
	
	public static float CR_LOSS_MULT_FOR_EmergencyForge = 0f;
	public static float REPAIR_MULT_FOR_EmergencyForge = 1f;
	public static float Max_Duration = 20f;
	
	public void applyEffectsBeforeShipCreation(HullSize hullSize, MutableShipStatsAPI stats, String id) {
		stats.getEmpDamageTakenMult().modifyMult("dpl_Precursor_Reboot", 0.02f);
	}
	
	public static class dpl_Precursor_RebootScript implements AdvanceableListener, HullDamageAboutToBeTakenListener{
		public ShipAPI ship;
		public float Progress = 0f;
		public float Health_old;
		public float Health_new;
		public float Duration = Max_Duration;
		public dpl_Precursor_RebootScript(ShipAPI ship) {
			this.ship = ship;
			this.Health_old = ship.getMaxHitpoints();
		}
		
		public boolean notifyAboutToTakeHullDamage(Object param, ShipAPI ship, Vector2f point, float damageAmount) {
			
			if (damageAmount >= ship.getMaxHitpoints()*0.1f) {
				float r1 = ship.getCollisionRadius();
				Color c = new Color(255,200,255,255);
				c = Misc.setAlpha(c, 255);
				c = Misc.interpolateColor(c, Color.white, 0.5f);
				ship.setJitter(this, c, 0.1f, 20, r1*0.5f);
				if (ship.getFluxTracker().showFloaty()) {
					Global.getCombatEngine().addFloatingTextAlways(ship.getLocation(),
							"Precursor Dimensional Resonance!",
							NeuralLinkScript.getFloatySize(ship), c, ship, 16f , 3.2f, 1f, 0f, 0f,
							1f);
				}
				return true;
			}
			return false;
		}

		public void advance(float amount) {
			String id = "dpl_phase_projection_modifier";
			if (ship.getOwner() == 0) {
				ship.setHitpoints(-1f);
			}
			
			Duration -= amount;
			
			Health_new = ship.getHitpoints();
			if (Health_old - Health_new >= ship.getMaxHitpoints() * 0.2f * amount) {
				ship.setHitpoints(Health_old - ship.getMaxHitpoints() * 0.2f * amount);
			}
			Health_old = ship.getHitpoints();
			
			if (Duration <= 0 && ship.isAlive()) {
				
				Color c = new Color(255,200,255,255);
				c = Misc.setAlpha(c, 255);
				c = Misc.interpolateColor(c, Color.white, 0.5f);
				if (Progress == 0f) {
					if (ship.getFluxTracker().showFloaty()) {
						Global.getCombatEngine().addFloatingTextAlways(ship.getLocation(),
								"Precursor Reboot!",
								NeuralLinkScript.getFloatySize(ship), c, ship, 16f , 3.2f, 1f, 0f, 0f,
								1f);
					}
				}
				
				ship.blockCommandForOneFrame(ShipCommand.USE_SYSTEM);
				Progress += amount * 0.5f;
				ship.getMutableStats().getHullDamageTakenMult().modifyMult(id, 0f);
				float r1 = ship.getCollisionRadius();
				ship.setJitter(this, c, 0.1f, 20, r1*0.5f);
				
				if (Progress >= 1f) {
					Global.getSoundPlayer().playSound("phase_anchor_vanish", 1f, 1f, ship.getLocation(), ship.getVelocity());
					float r = ship.getCollisionRadius();
					ship.setJitter(this, c, 0.5f, 20, r*0.5f);
					ship.setHitpoints(ship.getMaxHitpoints()*1f);
					ship.getFluxTracker().setCurrFlux(0);
					ship.getFluxTracker().setHardFlux(0);

			        ArmorGridAPI armorGrid = ship.getArmorGrid();
			        for (int i=0; i < armorGrid.getGrid().length; i++) {
			        	for (int j=0; j < armorGrid.getGrid()[0].length; j++) {
			        		int x = i;
					        int y = j;
					        float newArmor = armorGrid.getArmorValue(x, y);
					        float cellSize = armorGrid.getCellSize();

					        if (Float.compare(newArmor, armorGrid.getMaxArmorInCell()) < 0) {
					            armorGrid.setArmorValue(x, y, armorGrid.getMaxArmorInCell());

					            Vector2f cellLoc = getCellLocation(ship, x, y);
					                cellLoc.x += cellSize * 0.1f - cellSize * (float) Math.random();
					                cellLoc.y += cellSize * 0.1f - cellSize * (float) Math.random();
					        }
			        	}
			        }

			        ship.syncWithArmorGridState();
			        ship.syncWeaponDecalsWithArmorDamage();
			        ship.clearDamageDecals();
			        
					Duration = Max_Duration;
					Health_old = ship.getMaxHitpoints();
					Progress = 0f;
					ship.getMutableStats().getHullDamageTakenMult().unmodify(id);
				}
			}
		}
	}
	
	public static Vector2f getCellLocation(ShipAPI ship, float x, float y) {
        float xx = x - (ship.getArmorGrid().getGrid().length / 2f);
        float yy = y - (ship.getArmorGrid().getGrid()[0].length / 2f);
        float cellSize = ship.getArmorGrid().getCellSize();
        Vector2f cellLoc = new Vector2f();
        float theta = (float) (((ship.getFacing() - 90f) / 360f) * (Math.PI * 2.0));
        cellLoc.x = (float) (xx * Math.cos(theta) - yy * Math.sin(theta)) * cellSize + ship.getLocation().x;
        cellLoc.y = (float) (xx * Math.sin(theta) + yy * Math.cos(theta)) * cellSize + ship.getLocation().y;

        return cellLoc;
    }
	
	@Override
	public void applyEffectsAfterShipCreation(ShipAPI ship, String id) {
		ship.addListener(new dpl_Precursor_RebootScript(ship));
	}
	
	public String getDescriptionParam(int index, HullSize hullSize) {
		return null;
	}
}

