package data.hullmods.dpl_SpecialHanger;

import com.fs.starfarer.api.combat.MutableShipStatsAPI;
import com.fs.starfarer.api.combat.listeners.FighterOPCostModifier;
import com.fs.starfarer.api.loading.FighterWingSpecAPI;

public class dpl_SpecialHangerListener implements FighterOPCostModifier {
   public int getFighterOPCost(MutableShipStatsAPI stats, FighterWingSpecAPI fighter, int currCost) {
      if (!(fighter.hasTag("dpl_wing") || currCost <= 15)) 
    	  currCost = 99999;
      return currCost;
   }
}