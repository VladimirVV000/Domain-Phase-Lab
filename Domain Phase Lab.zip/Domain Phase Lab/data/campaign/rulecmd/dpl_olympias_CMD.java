package data.campaign.rulecmd;

import static com.fs.starfarer.api.impl.campaign.ids.FleetTypes.TASK_FORCE;

import java.util.List;
import java.util.Map;
import java.util.Random;

import org.lwjgl.util.vector.Vector2f;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.AICoreOfficerPlugin;
import com.fs.starfarer.api.campaign.CampaignFleetAPI;
import com.fs.starfarer.api.campaign.CargoAPI;
import com.fs.starfarer.api.campaign.FactionAPI;
import com.fs.starfarer.api.campaign.FleetAssignment;
import com.fs.starfarer.api.campaign.InteractionDialogAPI;
import com.fs.starfarer.api.campaign.OptionPanelAPI;
import com.fs.starfarer.api.campaign.PlanetAPI;
import com.fs.starfarer.api.campaign.SectorEntityToken;
import com.fs.starfarer.api.campaign.StarSystemAPI;
import com.fs.starfarer.api.campaign.TextPanelAPI;
import com.fs.starfarer.api.campaign.econ.MarketAPI;
import com.fs.starfarer.api.campaign.econ.MarketAPI.SurveyLevel;
import com.fs.starfarer.api.campaign.econ.MarketConditionAPI;
import com.fs.starfarer.api.campaign.rules.MemKeys;
import com.fs.starfarer.api.campaign.rules.MemoryAPI;
import com.fs.starfarer.api.characters.PersonAPI;
import com.fs.starfarer.api.combat.ShipVariantAPI;
import com.fs.starfarer.api.fleet.FleetAPI;
import com.fs.starfarer.api.fleet.FleetMemberAPI;
import com.fs.starfarer.api.fleet.FleetMemberType;
import com.fs.starfarer.api.impl.campaign.fleets.FleetFactoryV3;
import com.fs.starfarer.api.impl.campaign.fleets.FleetParamsV3;
import com.fs.starfarer.api.impl.campaign.ids.Commodities;
import com.fs.starfarer.api.impl.campaign.ids.Conditions;
import com.fs.starfarer.api.impl.campaign.ids.Factions;
import com.fs.starfarer.api.impl.campaign.ids.HullMods;
import com.fs.starfarer.api.impl.campaign.ids.Industries;
import com.fs.starfarer.api.impl.campaign.ids.MemFlags;
import com.fs.starfarer.api.impl.campaign.ids.People;
import com.fs.starfarer.api.impl.campaign.ids.Ranks;
import com.fs.starfarer.api.impl.campaign.ids.Submarkets;
import com.fs.starfarer.api.impl.campaign.intel.bases.LuddicPathBaseIntel;
import com.fs.starfarer.api.impl.campaign.missions.RecoverAPlanetkiller;
import com.fs.starfarer.api.impl.campaign.rulecmd.AddShip;
import com.fs.starfarer.api.impl.campaign.rulecmd.BaseCommandPlugin;
import com.fs.starfarer.api.impl.campaign.shared.SharedData;
import com.fs.starfarer.api.impl.campaign.submarkets.StoragePlugin;
import com.fs.starfarer.api.util.Misc;
import com.fs.starfarer.api.util.WeightedRandomPicker;
import com.fs.starfarer.api.util.Misc.Token;

/**
 * 
 *	dpl_jasp_CMD <action> <parameters>
 */
public class dpl_olympias_CMD extends BaseCommandPlugin {
	protected Random genRandom = null;
	
	public Random getGenRandom() {
		return genRandom;
	}

	public boolean execute(String ruleId, InteractionDialogAPI dialog, List<Token> params, Map<String, MemoryAPI> memoryMap) {
		if (dialog == null) return false;
		
		OptionPanelAPI options = dialog.getOptionPanel();
		TextPanelAPI text = dialog.getTextPanel();
		CampaignFleetAPI pf = Global.getSector().getPlayerFleet();
		CargoAPI cargo = pf.getCargo();
		
		String action = params.get(0).getString(memoryMap);
		
		MemoryAPI memory = memoryMap.get(MemKeys.LOCAL);
		if (memory == null) return false; // should not be possible unless there are other big problems already
				
		if ("spawnFleets".equals(action)) {
			StarSystemAPI system = pf.getStarSystem();
			SectorEntityToken Olympias = system.getEntityById("dpl_Olympias");
			if (Olympias == null) return false;
			List<FactionAPI> AllFactions = Global.getSector().getAllFactions();
			WeightedRandomPicker<FactionAPI> picker = new WeightedRandomPicker<FactionAPI>(getGenRandom());
			for (FactionAPI faction : AllFactions) {
				if (faction.isShowInIntelTab()) {
					picker.add(faction);
				}
			}
			picker.add(Global.getSector().getFaction(Factions.REMNANTS));
			picker.add(Global.getSector().getFaction(Factions.DERELICT));
			FactionAPI theFaction = picker.pick();
			if (theFaction.getId().equals(Factions.REMNANTS) || theFaction.getId().equals(Factions.REMNANTS)) {
				int j = (int) Math.round(Math.random()*1.5 + 1);
				for (int i=0; i<j; i++) {
					FleetParamsV3 params1 = new FleetParamsV3(
			                null,
			                null,
			                theFaction.getId(),
			                null,
			                TASK_FORCE,
			                750f, // combatPts
			                0f, // freighterPts
			                0f, // tankerPts
			                0f, // transportPts
			                0f, // linerPts
			                0f, // utilityPts
			                3f // qualityMod
			        );
			    	params1.averageSMods = 3;
			    	CampaignFleetAPI fleet1;
			    	fleet1 = FleetFactoryV3.createFleet(params1);

					Misc.makeHostile(fleet1);
					Misc.makeNoRepImpact(fleet1, "$dpl_OlympiasFleet");

					Vector2f pos = pf.getLocation();
					
					fleet1.getMemoryWithoutUpdate().set(MemFlags.MEMORY_KEY_MAKE_AGGRESSIVE, "$dpl_OlympiasFleet");
					fleet1.getAI().addAssignment(FleetAssignment.ATTACK_LOCATION, Olympias, 200f, null);
					system.addEntity(fleet1);
			        fleet1.setLocation(pos.x*1.5f+100*((float) Math.random()*2-1), pos.y*1.5f+100*((float) Math.random()*2-1));
				}
			} else {
				int j = (int) Math.round(Math.random()*1.5 + 1);
				for (int i=0; i<j; i++) {
					FleetParamsV3 params1 = new FleetParamsV3(
			                null,
			                null,
			                theFaction.getId(),
			                null,
			                TASK_FORCE,
			                1050f, // combatPts
			                0f, // freighterPts
			                0f, // tankerPts
			                0f, // transportPts
			                0f, // linerPts
			                0f, // utilityPts
			                3f // qualityMod
			        );
			    	params1.averageSMods = 3;
			    	CampaignFleetAPI fleet1;
			    	fleet1 = FleetFactoryV3.createFleet(params1);

					Misc.makeHostile(fleet1);
					Misc.makeNoRepImpact(fleet1, "$dpl_OlympiasFleet");

					fleet1.getMemoryWithoutUpdate().set(MemFlags.MEMORY_KEY_MAKE_AGGRESSIVE, "$dpl_OlympiasFleet");
					fleet1.getAI().addAssignment(FleetAssignment.ATTACK_LOCATION, Olympias, 200f, null);
					system.addEntity(fleet1);
			        Vector2f pos = pf.getLocation();
			        fleet1.setLocation(pos.x*1.5f+100*((float) Math.random()*2-1), pos.y*1.5f+100*((float) Math.random()*2-1));
				}
			}
		}
		return false;
	}
}
