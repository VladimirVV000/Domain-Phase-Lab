package data.campaign.rulecmd;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Random;

import org.lwjgl.util.vector.Vector2f;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.CampaignFleetAPI;
import com.fs.starfarer.api.campaign.CargoAPI;
import com.fs.starfarer.api.campaign.FactionAPI;
import com.fs.starfarer.api.campaign.InteractionDialogAPI;
import com.fs.starfarer.api.campaign.OptionPanelAPI;
import com.fs.starfarer.api.campaign.PlanetAPI;
import com.fs.starfarer.api.campaign.TextPanelAPI;
import com.fs.starfarer.api.campaign.econ.MarketAPI;
import com.fs.starfarer.api.campaign.econ.MarketAPI.SurveyLevel;
import com.fs.starfarer.api.campaign.econ.MarketConditionAPI;
import com.fs.starfarer.api.campaign.rules.MemKeys;
import com.fs.starfarer.api.campaign.rules.MemoryAPI;
import com.fs.starfarer.api.characters.PersonAPI;
import com.fs.starfarer.api.combat.ShipVariantAPI;
import com.fs.starfarer.api.fleet.FleetMemberAPI;
import com.fs.starfarer.api.fleet.FleetMemberType;
import com.fs.starfarer.api.impl.campaign.ids.Conditions;
import com.fs.starfarer.api.impl.campaign.ids.Factions;
import com.fs.starfarer.api.impl.campaign.ids.HullMods;
import com.fs.starfarer.api.impl.campaign.ids.Industries;
import com.fs.starfarer.api.impl.campaign.ids.MemFlags;
import com.fs.starfarer.api.impl.campaign.ids.People;
import com.fs.starfarer.api.impl.campaign.ids.Ranks;
import com.fs.starfarer.api.impl.campaign.ids.Submarkets;
import com.fs.starfarer.api.impl.campaign.intel.bases.LuddicPathBaseIntel;
import com.fs.starfarer.api.impl.campaign.missions.RecoverAPlanetkiller;
import com.fs.starfarer.api.impl.campaign.rulecmd.AddShip;
import com.fs.starfarer.api.impl.campaign.rulecmd.BaseCommandPlugin;
import com.fs.starfarer.api.impl.campaign.shared.SharedData;
import com.fs.starfarer.api.impl.campaign.submarkets.StoragePlugin;
import com.fs.starfarer.api.util.Misc;
import com.fs.starfarer.api.util.WeightedRandomPicker;
import com.fs.starfarer.api.util.Misc.Token;

/**
 * 
 *	dpl_jasp_CMD <action> <parameters>
 */
public class dpl_RossTradeCMD extends BaseCommandPlugin {
	protected Random genRandom = null;
	
	public Random getGenRandom() {
		return genRandom;
	}

	public boolean execute(String ruleId, InteractionDialogAPI dialog, List<Token> params, Map<String, MemoryAPI> memoryMap) {
		if (dialog == null) return false;
		
		OptionPanelAPI options = dialog.getOptionPanel();
		TextPanelAPI text = dialog.getTextPanel();
		CampaignFleetAPI pf = Global.getSector().getPlayerFleet();
		CargoAPI cargo = pf.getCargo();
		
		String action = params.get(0).getString(memoryMap);
		
		MemoryAPI memory = memoryMap.get(MemKeys.LOCAL);
		if (memory == null) return false; // should not be possible unless there are other big problems already
				
		if ("rollSmall".equals(action)) {
			int Seed = -1;
			boolean HasSeed = memory.getBoolean("$dpl_RossHasSeed");
			if (HasSeed) {
				Seed = memory.getInt("$dpl_RossSeed");
			} else {
				Seed = Math.round(1000000*(float) Math.random());
				memory.set("$dpl_RossSeed", Seed);
				memory.set("$dpl_RossHasSeed", true);
			}
			List<String> AllWeapons = new ArrayList<>();
			AllWeapons.add("dpl_black_hole");
			AllWeapons.add("dpl_weak_spot");
			AllWeapons.add("dpl_unstable_particle");
			AllWeapons.add("dpl_jingle");
			AllWeapons.add("dpl_nova_blaster");
			Random random1 = new Random(Seed);
			int i = random1.nextInt(AllWeapons.size());
			String theWeapon = AllWeapons.get(i);
			cargo.addWeapons(theWeapon, 1);
			
			Seed = Math.round(1000000*(float) random1.nextFloat());
			memory.set("$dpl_RossSeed", Seed);
			memory.set("$dpl_RossHasSeed", true);
			
		} else if ("rollMedium".equals(action)) {
			int Seed = -1;
			boolean HasSeed = memory.getBoolean("$dpl_RossHasSeed");
			if (HasSeed) {
				Seed = memory.getInt("$dpl_RossSeed");
			} else {
				Seed = Math.round(1000000*(float) Math.random());
				memory.set("$dpl_RossSeed", Seed);
				memory.set("$dpl_RossHasSeed", true);
			}
			List<String> AllWeapons = new ArrayList<>();
			AllWeapons.add("dpl_shield_disruptor");
			AllWeapons.add("dpl_chants");
			AllWeapons.add("dpl_vaporizer");
			AllWeapons.add("dpl_crotchets");
			AllWeapons.add("dpl_lightning_pulser");
			Random random1 = new Random(Seed);
			int i = random1.nextInt(AllWeapons.size());
			String theWeapon = AllWeapons.get(i);
			cargo.addWeapons(theWeapon, 1);
			
			Seed = Math.round(1000000*(float) random1.nextFloat());
			memory.set("$dpl_RossSeed", Seed);
			memory.set("$dpl_RossHasSeed", true);
			
		}
		return false;
	}
}
