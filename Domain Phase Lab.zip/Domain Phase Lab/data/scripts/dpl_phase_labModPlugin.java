package data.scripts;

import com.fs.starfarer.api.BaseModPlugin;
import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.PluginPick;
import com.fs.starfarer.api.campaign.CampaignPlugin;
import com.fs.starfarer.api.campaign.FactionAPI;
import com.fs.starfarer.api.campaign.SectorAPI;
import com.fs.starfarer.api.campaign.SectorEntityToken;
import com.fs.starfarer.api.campaign.StarSystemAPI;
import com.fs.starfarer.api.campaign.econ.MarketAPI;
import com.fs.starfarer.api.campaign.econ.Industry;
import com.fs.starfarer.api.impl.campaign.procgen.ProcgenUsedNames;
import com.fs.starfarer.api.characters.FullName;
import com.fs.starfarer.api.characters.PersonAPI;
import com.fs.starfarer.api.campaign.PersonImportance;
import com.fs.starfarer.api.characters.ImportantPeopleAPI;
import com.fs.starfarer.api.impl.campaign.events.OfficerManagerEvent;
import com.fs.starfarer.api.impl.campaign.ids.Commodities;
import com.fs.starfarer.api.impl.campaign.ids.Ranks;
import com.fs.starfarer.api.impl.campaign.ids.Skills;
import com.fs.starfarer.api.impl.campaign.ids.Tags;
import com.fs.starfarer.api.impl.campaign.intel.bar.events.BarEventManager;
import com.fs.starfarer.api.campaign.rules.MemoryAPI;
import com.fs.starfarer.api.campaign.BaseCampaignPlugin;

import com.fs.starfarer.api.impl.campaign.shared.SharedData;

import data.scripts.world.systems.dpl_proving_ground;

 
public class dpl_phase_labModPlugin extends BaseModPlugin {
	public static String ELIZA_LOVELACE = "eliza_lovelace";
	
	public static void newGenerate(SectorAPI sector) {
		ProcgenUsedNames.notifyUsed("dpl_phase_lab");
	}
	
	@Override
	public void onNewGame() {SharedData.getData().getPersonBountyEventData().addParticipatingFaction("dpl_phase_lab");
		SectorAPI sector = Global.getSector();
		boolean haveNexerelin = Global.getSettings().getModManager().isModEnabled("nexerelin");
		StarSystemAPI corvus = sector.getStarSystem("Corvus");
		if(!haveNexerelin || corvus != null) {
			new dpl_proving_ground().generate(sector);
		}
		FactionAPI player = sector.getFaction("player");
		FactionAPI hegemony = sector.getFaction("hegemony");
		FactionAPI tritachyon = sector.getFaction("tritachyon");
		FactionAPI pirates = sector.getFaction("pirates");
		FactionAPI church = sector.getFaction("luddic_church");
		FactionAPI path = sector.getFaction("luddic_path");
		FactionAPI indep = sector.getFaction("independent");
		FactionAPI diktat = sector.getFaction("sindrian_diktat");
		FactionAPI persean = sector.getFaction("persean");
		FactionAPI dpl_phase_lab = sector.getFaction("dpl_phase_lab");
		dpl_phase_lab.setRelationship(hegemony.getId(), 0.3f);
		dpl_phase_lab.setRelationship(persean.getId(), 0.1f);
		dpl_phase_lab.setRelationship(tritachyon.getId(), -0.5f);
		dpl_phase_lab.setRelationship(pirates.getId(), -1f);
		dpl_phase_lab.setRelationship(path.getId(), -1f);
	}
    
    @Override
    public void onNewGameAfterEconomyLoad() {
    	MarketAPI market1 = Global.getSector().getEconomy().getMarket("dpl_security");
    	if (market1 != null) {
    		Industry highcommand1 = market1.getIndustry("highcommand");
			highcommand1.setImproved(true);
			Industry refining1 = market1.getIndustry("refining");
			refining1.setImproved(true);
    	}

    	MarketAPI market2 = Global.getSector().getEconomy().getMarket("dpl_fuel_storage");
    	if (market2 != null) {
    		Industry highcommand2 = market2.getIndustry("highcommand");
			highcommand2.setImproved(true);
			Industry fuelprod2 = market2.getIndustry("fuelprod");
			fuelprod2.setImproved(true);
    	}
    	
    	ImportantPeopleAPI ip = Global.getSector().getImportantPeople();
        MarketAPI market3 = Global.getSector().getEconomy().getMarket("dpl_research_site_v");
        if (market3 != null) {
        	//Generating Eliza Storyline boolean values.
        	market3.getMemoryWithoutUpdate().set("$dpl_metEliza", false);
        	market3.getMemoryWithoutUpdate().set("$dpl_asked_remnant", false);
        	market3.getMemoryWithoutUpdate().set("$dpl_asked_leader", false);
        	market3.getMemoryWithoutUpdate().set("$dpl_asked_age", false);
        	market3.getMemoryWithoutUpdate().set("$dpl_asked_person", false);
        	market3.getMemoryWithoutUpdate().set("$dpl_asked_well", false);
        	market3.getMemoryWithoutUpdate().set("$dpl_asked_luddic", false);
        	
        	//Generating Eliza Lovelace.       	
            PersonAPI eliza_lovelace = Global.getFactory().createPerson();
            eliza_lovelace.setId(ELIZA_LOVELACE);
            eliza_lovelace.setFaction("dpl_phase_lab");
            eliza_lovelace.setGender(FullName.Gender.FEMALE);
            eliza_lovelace.setImportance(PersonImportance.VERY_HIGH);
            eliza_lovelace.setPostId(Ranks.POST_FACTION_LEADER);
            eliza_lovelace.setRankId(Ranks.FACTION_LEADER);
            eliza_lovelace.getName().setFirst("Eliza");
            eliza_lovelace.getName().setLast("Lovelace");
            eliza_lovelace.setPortraitSprite(Global.getSettings().getSpriteName("characters", "eliza_lovelace"));
            market3.getCommDirectory().addPerson(eliza_lovelace, 0);
			market3.addPerson(eliza_lovelace);
			ip.addPerson(eliza_lovelace);
			Industry highcommand3 = market3.getIndustry("highcommand");
			highcommand3.setImproved(true);
			Industry farming3 = market3.getIndustry("farming");
			farming3.setImproved(true);
        }
        
    	MarketAPI market4 = Global.getSector().getEconomy().getMarket("dpl_research_site_v_moon");
    	if (market4 != null) {
    		Industry highcommand4 = market4.getIndustry("highcommand");
			highcommand4.setImproved(true);
			Industry orbitalworks4 = market4.getIndustry("orbitalworks");
			orbitalworks4.setImproved(true);
    	}
    	
    	MarketAPI market5 = Global.getSector().getEconomy().getMarket("dpl_factory");
    	if (market5 != null) {
    		Industry highcommand5 = market5.getIndustry("highcommand");
			highcommand5.setImproved(true);
			Industry orbitalworks5 = market5.getIndustry("orbitalworks");
			orbitalworks5.setImproved(true);
    	}
    	
    	MarketAPI market6 = Global.getSector().getEconomy().getMarket("dpl_metallurgy_plant");
    	if (market6 != null) {
    		Industry highcommand6 = market6.getIndustry("highcommand");
			highcommand6.setImproved(true);
			Industry refining6 = market6.getIndustry("refining");
			refining6.setImproved(true);
    	}
    }

}