package data.scripts.world.systems;

import java.awt.Color;

import org.lwjgl.util.vector.Vector2f;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.JumpPointAPI;
import com.fs.starfarer.api.campaign.LocationAPI;
import com.fs.starfarer.api.campaign.OrbitAPI;
import com.fs.starfarer.api.campaign.PlanetAPI;
import com.fs.starfarer.api.campaign.SectorAPI;
import com.fs.starfarer.api.campaign.SectorEntityToken;
import com.fs.starfarer.api.campaign.StarSystemAPI;
import com.fs.starfarer.api.impl.campaign.ids.Conditions;
import com.fs.starfarer.api.impl.campaign.ids.Entities;
import com.fs.starfarer.api.impl.campaign.ids.StarTypes;
import com.fs.starfarer.api.impl.campaign.ids.Terrain;
import com.fs.starfarer.api.impl.campaign.procgen.StarAge;
import com.fs.starfarer.api.impl.campaign.procgen.StarSystemGenerator;
import com.fs.starfarer.api.impl.campaign.procgen.StarSystemGenerator.StarSystemType;
import com.fs.starfarer.api.impl.campaign.rulecmd.salvage.special.ShipRecoverySpecial.ShipCondition;
import com.fs.starfarer.api.impl.campaign.terrain.BaseRingTerrain.RingParams;
import com.fs.starfarer.api.impl.campaign.terrain.DebrisFieldTerrainPlugin.DebrisFieldParams;
import com.fs.starfarer.api.impl.campaign.terrain.DebrisFieldTerrainPlugin.DebrisFieldSource;
import com.fs.starfarer.api.impl.campaign.terrain.MagneticFieldTerrainPlugin.MagneticFieldParams;
import com.fs.starfarer.api.impl.campaign.procgen.NebulaEditor;
import com.fs.starfarer.api.impl.campaign.terrain.HyperspaceTerrainPlugin;
import com.fs.starfarer.api.util.Misc;

import data.scripts.world.dpl_phase_labAddEntities;

public class dpl_proving_ground {

	public void generate(SectorAPI sector) {
		StarSystemAPI system = sector.createStarSystem("DPL Proving Ground");
		LocationAPI hyper = Global.getSector().getHyperspace();
		
		system.setBackgroundTextureFilename("graphics/backgrounds/background4.jpg");

		PlanetAPI star = system.initStar("dpl_proving_ground", // unique id for this star
										 StarTypes.YELLOW, // id in planets.json
										 600f,		// radius (in pixels at default zoom)
										 150); // corona radius, from star edge
		
		PlanetAPI dpl_security = system.addPlanet("dpl_security", star, "Lab Security Department", "lava", 12, 100, 2025, 82);
		Misc.initConditionMarket(dpl_security);		
		dpl_security.getMarket().addCondition(Conditions.VERY_HOT);
		
		dpl_security.setCustomDescriptionId("dpl_security");		
		
		PlanetAPI dpl_fuel_storage = system.addPlanet("dpl_fuel_storage", star, "Lab Fuel Storage", "cryovolcanic", 5, 225, 3350, 136);
		Misc.initConditionMarket(dpl_fuel_storage);		
		dpl_fuel_storage.getMarket().addCondition(Conditions.NO_ATMOSPHERE);
		dpl_fuel_storage.getMarket().addCondition(Conditions.VOLATILES_PLENTIFUL);
		
		dpl_fuel_storage.setCustomDescriptionId("dpl_fuel_storage");
				
		
		PlanetAPI dpl_research_site_v = system.addPlanet("dpl_research_site_v", star, "Research Site V", "terran", 0, 200, 4425, 180);
		Misc.initConditionMarket(dpl_research_site_v);
		dpl_research_site_v.getMarket().addCondition(Conditions.RUINS_VAST);
		dpl_research_site_v.getMarket().getFirstCondition(Conditions.RUINS_VAST).setSurveyed(true);
		
		dpl_research_site_v.getMarket().addCondition(Conditions.HABITABLE);
		dpl_research_site_v.getMarket().addCondition(Conditions.MILD_CLIMATE);
		dpl_research_site_v.getMarket().addCondition(Conditions.SOLAR_ARRAY);
		dpl_research_site_v.getMarket().addCondition(Conditions.FARMLAND_BOUNTIFUL);
		dpl_research_site_v.getMarket().addCondition(Conditions.ORGANICS_PLENTIFUL);
		dpl_research_site_v.getMarket().addCondition(Conditions.ORE_ULTRARICH);
		
		dpl_research_site_v.setCustomDescriptionId("dpl_research_site_v");
		dpl_research_site_v.getSpec().setGlowTexture(Global.getSettings().getSpriteName("hab_glows", "volturn"));
		dpl_research_site_v.getSpec().setGlowColor(new Color(255,255,255,255));
		dpl_research_site_v.getSpec().setUseReverseLightForGlow(true);
		dpl_research_site_v.applySpecChanges();
		
		SectorEntityToken dpl_mirror1 = system.addCustomEntity("dpl_mirror1", // unique id
				 "Stellar Mirror I", // name - if null, defaultName from custom_entities.json will be used
				 "stellar_mirror", // type of object, defined in custom_entities.json
				 "dpl_phase_lab"); // faction
		
		dpl_mirror1.setCircularOrbitPointingDown(dpl_research_site_v, 24, 300, 15);
		
		SectorEntityToken dpl_mirror2 = system.addCustomEntity("dpl_mirror2", // unique id
				 "Stellar Mirror II", // name - if null, defaultName from custom_entities.json will be used
				 "stellar_mirror", // type of object, defined in custom_entities.json
				 "dpl_phase_lab"); // faction
		
		dpl_mirror2.setCircularOrbitPointingDown(dpl_research_site_v, 48, 300, 15);
		
		SectorEntityToken dpl_mirror3 = system.addCustomEntity("dpl_mirror3", // unique id
				 "Stellar Mirror III", // name - if null, defaultName from custom_entities.json will be used
				 "stellar_mirror", // type of object, defined in custom_entities.json
				 "dpl_phase_lab"); // faction
		
		dpl_mirror3.setCircularOrbitPointingDown(dpl_research_site_v, 72, 300, 15);
		
		PlanetAPI dpl_research_site_v_moon = system.addPlanet("dpl_research_site_v_moon", dpl_research_site_v, "Research Site V Moon", "rocky_metallic", 30, 50, 700, 30);
		Misc.initConditionMarket(dpl_research_site_v_moon);		
		dpl_research_site_v_moon.getMarket().addCondition(Conditions.VOLATILES_PLENTIFUL);
		dpl_research_site_v_moon.getMarket().addCondition(Conditions.ORE_ULTRARICH);
		dpl_research_site_v_moon.getMarket().addCondition(Conditions.RARE_ORE_ULTRARICH);
		
		dpl_research_site_v_moon.setCustomDescriptionId("dpl_research_site_v_moon");

		PlanetAPI dpl_factory = system.addPlanet("dpl_factory", star, "Lab Factory", "rocky_metallic", 90, 160, 5420, 220);
		Misc.initConditionMarket(dpl_factory);		
		dpl_factory.getMarket().addCondition(Conditions.ORE_ULTRARICH);
		dpl_factory.getMarket().addCondition(Conditions.RARE_ORE_ULTRARICH);
		
		dpl_factory.setCustomDescriptionId("dpl_factory");
		
		PlanetAPI dpl_metallurgy_plant = system.addPlanet("dpl_metallurgy_plant", star, "Lab Metallurgy Plant", "barren", 150, 120, 6550, 266);
		Misc.initConditionMarket(dpl_metallurgy_plant);		
		dpl_metallurgy_plant.getMarket().addCondition(Conditions.NO_ATMOSPHERE);
		
		dpl_metallurgy_plant.setCustomDescriptionId("dpl_metallurgy_plant");
		
		// Asteroid belts

		system.addAsteroidBelt(star, 100, 7960, 256, 150, 250, Terrain.ASTEROID_BELT, null);		
				
		// Proving Ground Relay - L5 (behind); well, okay, not quite the L5. But whatever.
		SectorEntityToken dpl_proving_ground_relay = system.addCustomEntity("dpl_proving_ground_relay", // unique id
				 "Proving Ground Relay", // name - if null, defaultName from custom_entities.json will be used
				 "comm_relay", // type of object, defined in custom_entities.json
				 "dpl_phase_lab"); // faction
		
		dpl_proving_ground_relay.setCircularOrbitPointingDown(star, 30, 6000, 244);
		
		SectorEntityToken dpl_proving_ground_array = system.addCustomEntity("dpl_proving_ground_array", // unique id
				 "Proving Ground Array", // name - if null, defaultName from custom_entities.json will be used
				 "sensor_array_makeshift", // type of object, defined in custom_entities.json
				 "dpl_phase_lab"); // faction
		
		dpl_proving_ground_array.setCircularOrbitPointingDown(star, 150, 6000, 244);
		
		SectorEntityToken dpl_proving_ground_buoy = system.addCustomEntity("dpl_proving_ground_buoy", // unique id
				 "Proving Ground Buoy", // name - if null, defaultName from custom_entities.json will be used
				 "nav_buoy_makeshift", // type of object, defined in custom_entities.json
				 "dpl_phase_lab"); // faction
		
		dpl_proving_ground_buoy.setCircularOrbitPointingDown(star, 270, 6000, 244);
		
		JumpPointAPI inner_jump_point = Global.getFactory().createJumpPoint("inner_jump_point", "Inner System Jump-point");
		OrbitAPI inner_orbit = Global.getFactory().createCircularOrbit(star, 0, 3200, 130);
		inner_jump_point.setOrbit(inner_orbit);
		inner_jump_point.setStandardWormholeToHyperspaceVisual();
		system.addEntity(inner_jump_point);
		
		JumpPointAPI outer_jump_point = Global.getFactory().createJumpPoint("outer_jump_point", "Outer System Jump-point");
		OrbitAPI outer_orbit = Global.getFactory().createCircularOrbit(star, 165, 8240, 335);
		outer_jump_point.setOrbit(outer_orbit);
		outer_jump_point.setStandardWormholeToHyperspaceVisual();
		system.addEntity(outer_jump_point);
		
		system.autogenerateHyperspaceJumpPoints(true, true);
		
		HyperspaceTerrainPlugin plugin = (HyperspaceTerrainPlugin) Misc.getHyperspaceTerrain().getPlugin();
		NebulaEditor editor = new NebulaEditor(plugin);
		float minRadius = plugin.getTileSize() * 2f;
		float radius = system.getMaxRadiusInHyperspace();
		editor.clearArc(system.getLocation().x, system.getLocation().y, 0f, radius + minRadius * 0.5f, 0f, 360f);
		editor.clearArc(system.getLocation().x, system.getLocation().y, 0f, radius + minRadius, 0f, 360f, 0.25f);

	}


}
