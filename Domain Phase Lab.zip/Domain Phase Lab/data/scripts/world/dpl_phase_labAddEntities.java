package data.scripts.world;

import static com.fs.starfarer.api.impl.campaign.ids.FleetTypes.PATROL_LARGE;

import java.util.List;

import org.lwjgl.util.vector.Vector2f;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.CampaignFleetAPI;
import com.fs.starfarer.api.campaign.SectorEntityToken;
import com.fs.starfarer.api.campaign.StarSystemAPI;
import com.fs.starfarer.api.fleet.FleetMemberAPI;
import com.fs.starfarer.api.impl.campaign.DerelictShipEntityPlugin.DerelictShipData;
import com.fs.starfarer.api.impl.campaign.fleets.FleetFactoryV3;
import com.fs.starfarer.api.impl.campaign.fleets.FleetParamsV3;
import com.fs.starfarer.api.impl.campaign.ids.Entities;
import com.fs.starfarer.api.impl.campaign.ids.Factions;
import com.fs.starfarer.api.impl.campaign.ids.Tags;
import com.fs.starfarer.api.impl.campaign.procgen.themes.BaseThemeGenerator;
import com.fs.starfarer.api.impl.campaign.procgen.themes.SalvageSpecialAssigner.ShipRecoverySpecialCreator;
import com.fs.starfarer.api.impl.campaign.rulecmd.salvage.special.ShipRecoverySpecial;
import com.fs.starfarer.api.impl.campaign.rulecmd.salvage.special.ShipRecoverySpecial.PerShipData;
import com.fs.starfarer.api.impl.campaign.rulecmd.salvage.special.ShipRecoverySpecial.ShipCondition;
import com.fs.starfarer.api.impl.campaign.rulecmd.salvage.special.ShipRecoverySpecial.ShipRecoverySpecialData;
import com.fs.starfarer.api.loading.VariantSource;
import com.fs.starfarer.api.util.Misc;

public class dpl_phase_labAddEntities {
    
    public static SectorEntityToken addDerelict(StarSystemAPI system, SectorEntityToken focus, String variantId,
            ShipCondition condition, float orbitRadius, boolean recoverable, boolean tag, String tagstring) {        
        
        DerelictShipData params = new DerelictShipData(new PerShipData(variantId, condition), false);
        SectorEntityToken ship = BaseThemeGenerator.addSalvageEntity(system, Entities.WRECK, Factions.NEUTRAL, params);
        ship.setDiscoverable(true);

        float orbitDays = orbitRadius / (10f + (float) Math.random() * 5f);
        ship.setCircularOrbit(focus, (float) Math.random() * 360f, orbitRadius, orbitDays);

        if (recoverable) {
            ShipRecoverySpecialCreator creator = new ShipRecoverySpecialCreator(null, 0, 0, false, null, null);
            Misc.setSalvageSpecial(ship, creator.createSpecial(ship, null));
        }
        if (tag) {
			ship.getMemoryWithoutUpdate().set(tagstring, true);
		}
        return ship;
    }
    
    public static SectorEntityToken spawnNamedWreck(Vector2f loc, StarSystemAPI system, String FactionId, String vId, String shipName, boolean recoverable) {
        String variantId = vId;
        Object params = new DerelictShipData(
            new PerShipData(
                Global.getSettings().getVariant(variantId), ShipRecoverySpecial.ShipCondition.WRECKED,
                shipName, FactionId, 0f
            ), false
        );

        SectorEntityToken shipWreck = BaseThemeGenerator.addSalvageEntity(
            system, Entities.WRECK, Factions.NEUTRAL, params
        );
        
        if (recoverable) {
        	ShipRecoverySpecialData data = new ShipRecoverySpecialData(null);
            PerShipData copy = new PerShipData(
                    Global.getSettings().getVariant(variantId), ShipRecoverySpecial.ShipCondition.WRECKED,
                    shipName, FactionId, 0f
                );
            data.addShip(copy);

            Misc.setSalvageSpecial(shipWreck, data);
        }

        shipWreck.setDiscoverable(true);
        shipWreck.setLocation(loc.x, loc.y);
        
        return shipWreck;
    }
    
    //This function spawns a fleet belonging to faction1 that is composed with ships from faction2.
    //This only spawns the fleet data! You need to add the fleet into your system separately. Giving you more freedom to
    //modify your fleets before you actually spawn them. If you don't want a second faction, imput null for faction2.
    public static CampaignFleetAPI spawn_fleet_2fctn(String name, String faction1, String faction2, String fleetType, float combatPts, float freighterPts, float tankerPts, float transportPts, float linerPts, float utilityPts, float qualityMod) {
    	FleetParamsV3 params = new FleetParamsV3(
                null,
                null,
                faction1,
                null,
                fleetType,
                combatPts, // combatPts
                freighterPts, // freighterPts
                tankerPts, // tankerPts
                transportPts, // transportPts
                linerPts, // linerPts
                utilityPts, // utilityPts
                qualityMod // qualityMod
        );
    	
    	CampaignFleetAPI target;
    	
    	if (faction2 != null) {
    		CampaignFleetAPI fleet = FleetFactoryV3.createFleet(params);
        	
        	target = Global.getFactory().createEmptyFleet(faction2, name, true);
        	List<FleetMemberAPI> members = fleet.getFleetData().getMembersListCopy();
    		for (FleetMemberAPI curr : members) {
    			target.getFleetData().addFleetMember(curr);
    		}
    		target.getFleetData().sort();
    	} else {
    		target = FleetFactoryV3.createFleet(params);
    	}
    	
    	return target;
    }
}