package data.scripts.world;

import com.fs.starfarer.api.campaign.FactionAPI;
import com.fs.starfarer.api.campaign.econ.MarketAPI;
import com.fs.starfarer.api.characters.PersonAPI;
import com.fs.starfarer.api.impl.campaign.intel.contacts.ContactIntel;
import com.fs.starfarer.api.impl.campaign.missions.hub.BaseMissionHub;
import com.fs.starfarer.api.ui.LabelAPI;
import com.fs.starfarer.api.ui.TooltipMakerAPI;
import com.fs.starfarer.api.ui.UIComponentAPI;
import com.fs.starfarer.api.util.Misc;
import com.fs.starfarer.api.util.Pair;

import java.awt.Color;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Contacts that can't be dismissed or prioritized and don't count towards the limit.
 */
public class dpl_ContactIntel extends ContactIntel {
	
	public dpl_ContactIntel(PersonAPI person, MarketAPI market) {
		super(person, market);
	}
	
	// don't lose importance when relocating
	@Override
	public void relocateToMarket(MarketAPI other, boolean withIntelUpdate) {
		super.relocateToMarket(other, withIntelUpdate);
		person.setImportance(person.getImportance().next());
	}
	
}
