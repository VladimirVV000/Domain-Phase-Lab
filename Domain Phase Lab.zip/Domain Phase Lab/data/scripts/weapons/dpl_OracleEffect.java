package data.scripts.weapons;

import java.awt.Color;
import java.util.Iterator;

import org.lwjgl.util.vector.Vector2f;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.combat.BeamAPI;
import com.fs.starfarer.api.combat.BeamEffectPlugin;
import com.fs.starfarer.api.combat.CollisionClass;
import com.fs.starfarer.api.combat.CombatEngineAPI;
import com.fs.starfarer.api.combat.CombatEntityAPI;
import com.fs.starfarer.api.combat.DamageType;
import com.fs.starfarer.api.combat.DamagingProjectileAPI;
import com.fs.starfarer.api.combat.EmpArcEntityAPI;
import com.fs.starfarer.api.combat.MissileAPI;
import com.fs.starfarer.api.combat.ShipAPI;
import com.fs.starfarer.api.combat.WeaponAPI;
import com.fs.starfarer.api.impl.campaign.ids.Stats;
import com.fs.starfarer.api.util.IntervalUtil;
import com.fs.starfarer.api.util.Misc;

/**
 * Summarized all effects for oracle
 * @author Vladimir
 */

public class dpl_OracleEffect implements BeamEffectPlugin {

	private IntervalUtil fireInterval = new IntervalUtil(0.1f, 0.2f);
	private boolean wasZero = true;
	
	public void advance(float amount, CombatEngineAPI engine, BeamAPI beam) {
		
		//Do the simpler check to see if anything gets hit
		if (beam.getWeapon().getShip() == null) {
            return;
        }
		
        if (beam.didDamageThisFrame()) {
        	//Always check the entity instance before calling its methods
        	//Destroys neutral ship hulks
            if (beam.getDamageTarget() instanceof CombatEntityAPI && beam.getDamageTarget().getOwner() == 100){
            ShipAPI ship = beam.getWeapon().getShip();
            engine.applyDamage(beam.getDamageTarget(), beam.getDamageTarget().getLocation(), 1000000f, DamageType.HIGH_EXPLOSIVE, 0f, true, false, ship, false);
            }
    	}
    	
        //Generates high explosive arcs for targets with heavy shield
		CombatEntityAPI target = beam.getDamageTarget();
		if (target instanceof ShipAPI && beam.getBrightness() >= 0.9f) {
			float dur = beam.getDamage().getDpsDuration();
			// needed because when the ship is in fast-time, dpsDuration will not be reset every frame as it should be
			if (!wasZero) dur = 0;
			wasZero = beam.getDamage().getDpsDuration() <= 0;
			fireInterval.advance(dur);
			boolean hitShield = target.getShield() != null && target.getShield().isWithinArc(beam.getTo());
			ShipAPI ship = (ShipAPI) target;
			if (fireInterval.intervalElapsed()) {
				if (hitShield) {
					Vector2f point = beam.getRayEndPrevFrame();
					float emp = 0;
					float dam = beam.getDamage().getDamage() + beam.getDamageTarget().getHitpoints()*1.25f;
					engine.spawnEmpArcPierceShields(
									   beam.getSource(), point, beam.getDamageTarget(), beam.getDamageTarget(),
									   DamageType.HIGH_EXPLOSIVE, 
									   dam, // damage
									   emp, // emp 
									   100000f, // max range 
									   "shock_repeater_emp_impact",
									   beam.getWidth() + 5f,
									   beam.getFringeColor(),
									   beam.getCoreColor()
									   );
				}
				//Does more damage to more hull points
			}
            if (!hitShield){
            float dam2 = 100000f;
            engine.applyDamage(beam.getDamageTarget(), beam.getDamageTarget().getLocation(), dam2, DamageType.HIGH_EXPLOSIVE, 0f, true, false, ship, false);
            }
            if (ship.isStation() || ship.isStationModule()) {
            	allStationTargets(ship, engine);
            }
		}
	}
	
	public void allStationTargets(CombatEntityAPI ship, CombatEngineAPI engine) {
		float range = ship.getCollisionRadius()*3.5f;
		Vector2f from = ship.getLocation();
		
		Iterator<Object> iter = Global.getCombatEngine().getAllObjectGrid().getCheckIterator(from,
																			range * 2f, range * 2f);
		while (iter.hasNext()) {
			Object o = iter.next();
			if (!(o instanceof ShipAPI)) continue;
			ShipAPI other = (ShipAPI) o;
			if (!other.isAlive()) continue;
			if (!other.isStationModule() || other.getVariant().hasHullMod("vastbulk")) continue;
			if (other.getCollisionClass() == CollisionClass.NONE) continue;
			float dist = Misc.getDistance(from, other.getLocation());
			if (dist < 2) continue;
			if (dist > range) continue;
			engine.spawnEmpArcPierceShields(
					   null, ship.getLocation(), ship, other,
					   DamageType.HIGH_EXPLOSIVE, 
					   1f, // damage
					   0f, // emp 
					   100000f, // max range 
					   "shock_repeater_emp_impact",
					   100f,
					   new Color(150, 100, 255, 255),
					   new Color(255, 255, 255, 255)
					   );
			engine.applyDamage(other, other.getLocation(), 1000000f, DamageType.HIGH_EXPLOSIVE, 0f, true, false, ship, false);
		}
	}
}
