package data.scripts.weapons;

import java.awt.Color;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import org.lwjgl.util.vector.Vector2f;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.combat.CombatEngineAPI;
import com.fs.starfarer.api.combat.CombatEntityAPI;
import com.fs.starfarer.api.combat.DamageType;
import com.fs.starfarer.api.combat.DamagingProjectileAPI;
import com.fs.starfarer.api.combat.MissileAPI;
import com.fs.starfarer.api.combat.OnFireEffectPlugin;
import com.fs.starfarer.api.combat.OnHitEffectPlugin;
import com.fs.starfarer.api.combat.ShipAPI;
import com.fs.starfarer.api.combat.WeaponAPI;
import com.fs.starfarer.api.combat.listeners.ApplyDamageResultAPI;
import com.fs.starfarer.api.impl.combat.NegativeExplosionVisual.NEParams;
import com.fs.starfarer.api.impl.combat.RiftCascadeEffect;
import com.fs.starfarer.api.impl.combat.RiftCascadeMineExplosion;
import com.fs.starfarer.api.loading.MissileSpecAPI;
import com.fs.starfarer.api.util.Misc;

/**
 * IMPORTANT: will be multiple instances of this, one for the the OnFire (per weapon) and one for the OnHit (per torpedo) effects.
 * 
 * (Well, no data members, so not *that* important.)
 */
public class dpl_song_of_creationEffect implements OnHitEffectPlugin {
	
	public static final float INITIAL_BLAST_RADIUS = 450f;
	public static final float EXPANSION_BLAST_DPS = 5000f;
    public static final float EXPANSION_RATE = 150f;
    public static final float EXPANSION_TIME = 5f;
    private static final Color MIGHT_COLOR_1 = new Color(50, 125, 255, 100);

	public void onHit(DamagingProjectileAPI projectile, CombatEntityAPI target, Vector2f point, boolean shieldHit, ApplyDamageResultAPI damageResult, CombatEngineAPI engine) {
			Vector2f originalLoc = projectile.getSpawnLocation();
			boolean isFar = (Misc.getDistance(point, originalLoc)>1000f);
			if (isFar) {
				explode(projectile, point, 1f);
            }
	}
	
	public static List<ShipAPI> getShipsWithinRange(Vector2f location, float range) {
        List<ShipAPI> ships = new ArrayList<>();

        for (ShipAPI tmp : Global.getCombatEngine().getShips()) {
            if (tmp.isShuttlePod()) {
                continue;
            }

            if (Misc.getDistance(tmp.getLocation(), location) <= range) {
                ships.add(tmp);
            }
        }

        return ships;
    }
	
	public static List<CombatEntityAPI> getAsteroidsWithinRange(Vector2f location, float range) {
        List<CombatEntityAPI> asteroids = new ArrayList<>();

        for (CombatEntityAPI tmp : Global.getCombatEngine().getAsteroids()) {
            if (Misc.getDistance(tmp.getLocation(), location) <= range) {
                asteroids.add(tmp);
            }
        }

        return asteroids;
    }
	
	public static List<MissileAPI> getMissilesWithinRange(Vector2f location, float range) {
        List<MissileAPI> missiles = new ArrayList<>();

        for (MissileAPI tmp : Global.getCombatEngine().getMissiles()) {
            if (Misc.getDistance(tmp.getLocation(), location) <= range) {
                missiles.add(tmp);
            }
        }

        return missiles;
    }
	
	public static void explode(DamagingProjectileAPI projectile, Vector2f loc, float attenuate) {
		
		ShipAPI source = projectile.getSource();

        CombatEngineAPI engine = Global.getCombatEngine();

        List<ShipAPI> targets = getShipsWithinRange(loc, EXPANSION_TIME * EXPANSION_RATE * 0.7f);

        float blastDamage = 5f*projectile.getDamage().getDamage() * (float) Math.sqrt(attenuate);
        float blastRadius = INITIAL_BLAST_RADIUS * attenuate;
        float expansionTime = EXPANSION_TIME * attenuate;
        float expansionRate = EXPANSION_RATE * ((float) Math.sqrt(attenuate));


        for (ShipAPI target : targets) {

            if (!target.isAlive()) {
                continue;
            }
            if (target.isPhased()) {
                continue;
            }
            
            Vector2f point = new Vector2f(target.getLocation());
            Vector2f diff = Misc.getDiff(loc, point);
            float norm = Misc.getDistance(loc, point);
            float r = target.getCollisionRadius();
            Vector2f best = new Vector2f();
            if (norm <= r) {
            	best = loc;
            } else {
            	best.x = point.x + 0.8f * diff.x * r/norm;
                best.y = point.y + 0.8f * diff.y * r/norm;
            }
            engine.applyDamage(target, best,
                    blastDamage * (1-(Misc.getDistance(best, loc)/(EXPANSION_TIME * EXPANSION_RATE))),
                    DamageType.HIGH_EXPLOSIVE, 0f, true, false, source);
        }

        List<CombatEntityAPI> rocks = getAsteroidsWithinRange(loc, blastRadius);
        for (CombatEntityAPI rock : rocks) {
            engine.applyDamage(rock, rock.getLocation(),
                    blastDamage * (1-(Misc.getDistance(rock.getLocation(), loc)/(EXPANSION_TIME * EXPANSION_RATE/2))),
                    DamageType.HIGH_EXPLOSIVE, 0f, true, false, source);
        }

        List<MissileAPI> missiles = getMissilesWithinRange(loc, blastRadius);
        for (MissileAPI missile : missiles) {
            engine.applyDamage(missile, missile.getLocation(),
                    blastDamage * (1-(Misc.getDistance(missile.getLocation(), loc)/(EXPANSION_TIME * EXPANSION_RATE/2))),
                    DamageType.HIGH_EXPLOSIVE, 0f, true, false, source);
        }

        for (int i = 0; i < 600 * attenuate; i++) {
        	if (i % 6 == 0) {
        		Vector2f vel = Misc.getUnitVectorAtDegreeAngle((float) Math.random() * 360f);
            	vel.x = (float) (vel.x * expansionRate * (0.95+Math.random()*0.1)*0.5f);
            	vel.y = (float) (vel.y * expansionRate * (0.95+Math.random()*0.1)*0.5f);
            	int r = (int) (25 + Math.random()*25);
            	int g = (int) (100 + Math.random()*50);
            	int b = (int) (200 + Math.random()*50);
        		engine.addSmoothParticle(loc, vel, 15f, 1, (float) Math.random() * expansionTime * 0.25f + expansionTime * 0.5f, new Color(155,200,255,255));
        	}
            if (i % 24 == 0) {
            	Vector2f vel = Misc.getUnitVectorAtDegreeAngle((float) Math.random() * 360f);
            	vel.x = (float) (vel.x * expansionRate * (0.95+Math.random()*0.1));
            	vel.y = (float) (vel.y * expansionRate * (0.95+Math.random()*0.1));
            	int r = (int) (25 + Math.random()*25);
            	int g = (int) (100 + Math.random()*50);
            	int b = (int) (200 + Math.random()*50);
                engine.spawnExplosion(loc, vel, new Color(r,g,b,35), ((float) Math.random() * 200f + 100f) * attenuate, (float) Math.random() * expansionTime * 0.2f + expansionTime * 0.5f);
            }
        }

        engine.spawnExplosion(loc, new Vector2f(), MIGHT_COLOR_1, 500f * attenuate, 7f * (float) Math.sqrt(attenuate));

        float distanceToHead = Misc.getDistance(loc, Global.getCombatEngine().getViewport().getCenter());
        if (distanceToHead <= 1500f) {
            float refDist = Math.max(500f, 1000f * attenuate);
            float vol = (float) Math.sqrt(attenuate) * refDist / Math.max(refDist, distanceToHead);
            Global.getSoundPlayer().playUISound("dpl_ship_explosion", 1f / (float) Math.pow(attenuate, 0.25), vol);
        } else {
            float refDist = Math.max(1000f, 2000f * attenuate);
            float vol = (float) Math.sqrt(attenuate) * refDist / Math.max(refDist, distanceToHead);
            Global.getSoundPlayer().playUISound("dpl_ship_explosion", 0.5f / (float) Math.pow(attenuate, 0.25), vol);
        }
    }
}




