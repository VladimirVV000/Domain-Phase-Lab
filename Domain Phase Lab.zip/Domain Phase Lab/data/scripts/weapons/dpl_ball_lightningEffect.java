package data.scripts.weapons;

import java.awt.Color;

import org.lwjgl.util.vector.Vector2f;

import com.fs.starfarer.api.combat.CombatEngineAPI;
import com.fs.starfarer.api.combat.CombatEntityAPI;
import com.fs.starfarer.api.combat.DamageType;
import com.fs.starfarer.api.combat.DamagingProjectileAPI;
import com.fs.starfarer.api.combat.OnHitEffectPlugin;
import com.fs.starfarer.api.combat.ShipAPI;
import com.fs.starfarer.api.combat.listeners.ApplyDamageResultAPI;
import com.fs.starfarer.api.impl.campaign.ids.Stats;

public class dpl_ball_lightningEffect implements OnHitEffectPlugin {
	
	public static int MAXARC = 12;
	
	public void onHit(DamagingProjectileAPI projectile, CombatEntityAPI target,
					  Vector2f point, boolean shieldHit, ApplyDamageResultAPI damageResult, CombatEngineAPI engine) {
		if (target instanceof ShipAPI) {
			ShipAPI ship = (ShipAPI) target;
			float pierceChance = 1f;
			pierceChance *= ship.getMutableStats().getDynamic().getValue(Stats.SHIELD_PIERCED_MULT);
			boolean piercedShield = shieldHit && (float) Math.random() < pierceChance;
			
			if (!shieldHit || piercedShield) {
				float emp = projectile.getEmpAmount();
				float dam = projectile.getDamageAmount()/MAXARC; // this should be 1 for regular and a bunch for high-frequency
				for (int i=0; i <= MAXARC; i++) {
					engine.spawnEmpArcPierceShields(projectile.getSource(), point, target, target,
							   projectile.getDamageType(), 
							   dam,
							   emp, // emp 
							   100000f, // max range 
							   "mote_attractor_impact_emp_arc",
							   20f, // thickness
							   new Color(50,100,255,255),
							   new Color(255,255,255,255)
							   );
				}
		}
	}
//			Global.getSoundPlayer().playLoop("system_emp_emitter_loop", 
//											 beam.getDamageTarget(), 1.5f, beam.getBrightness() * 0.5f,
//											 beam.getTo(), new Vector2f());
	}
}
